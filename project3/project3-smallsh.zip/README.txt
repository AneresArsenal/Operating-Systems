# Program 3 - smallsh


Program includes two files:
1. makefile
2. smallsh.c

a. To compile the file, type the following into your command line:
make compile

b. To delete the compiled file, type the following into your command line:
make clean

c. To run the compiled file, you can choose to run the program in two ways as follow:
make run
smallsh